datablock PrecipitationData(HeavyRain)
{
   dropTexture = "./rain";
   splashTexture = "./splash";
   dropSize = 0.5;
   splashSize = 0.5;
   useTrueBillboards = false;
   splashMS = 200;
};