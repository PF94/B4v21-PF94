//Prefs Init

if(isFile(%file = "config/server/JVS/Doors/prefs.cs"))
{
	exec(%file);
}

if($JVS::Doors::Category $= "")
{
	$JVS::Doors::Category = "JVS";
}

if($JVS::Doors::MaxDoorsPerClient < 0 || $JVS::Doors::MaxDoorsPerClient $= "")
{
	$JVS::Doors::MaxDoorsPerClient = 25;
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}

	RTB_registerPref("Door Brick Category","JVS Doors","$JVS::Doors::Category","string 10","JVS_Doors","JVS",1,1);
	RTB_registerPref("Max Doors Per Client","JVS Doors","$JVS::Doors::MaxDoorsPerClient","int 0 9999","JVS_Doors",25,0,0);
}

//Audio Datablocks

if(!isObject(doorBuzzerSound))
{
	datablock AudioProfile(doorBuzzerSound)
	{
		filename = "Add-Ons/JVS_Doors/sounds/doorBuzzer.wav";
		description = AudioClose3d;
		preload = true;
	};
}

if(!isObject(doorClearSound))
{
	datablock AudioProfile(doorClearSound)
	{
		filename = "base/data/sound/brickClear.wav";
		description = Audio2d;
		preload = true;
	};
}

//Door Debris Particle Emitter Datablocks

if(!isObject(doorParticleDebris))
{
	datablock ParticleData(doorParticleDebris)
	{
		dragCoefficient = 3.0;
		windCoefficient = 0.0;
		gravityCoefficient = -0.5;
		inheritedVelFactor = 0.0;
		constantAcceleration = 0.0;
		lifetimeMS = 500;
		lifetimeVarianceMS = 150;
		spinSpeed = 10.0;
		spinRandomMin = -50.0;
		spinRandomMax = 50.0;
		useInvAlpha = true;
		animateTexture = false;
		textureName = "base/data/particles/cloud";
		colors[0] = "0.0 0.0 0.0 0.0";
		colors[1] = "0.0 0.0 0.0 0.250";
		colors[2] = "0.0 0.0 0.0 0.0";
		sizes[0] = 1.50;
		sizes[1] = 2.50;
		sizes[2] = 3.50;
		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};
}

if(!isObject(doorEmitterDebris))
{
	datablock ParticleEmitterData(doorEmitterDebris)
	{
		ejectionPeriodMS = 90;
		periodVarianceMS = 0;
		ejectionVelocity = 0.0;
		velocityVariance = 0.0;
		ejectionOffset = 1.0;
		thetaMin = 0;
		thetaMax = 0;
		phiReferenceVel = 0;
		phiVariance = 360;
		overrideAdvance = false;
		particles = "doorParticleDebris";
	};
}

//Script Objects

if(!isObject(DoorListSO))
{
	new ScriptObject(DoorListSO)
	{
		numDoors = 0;
	};
}

if(!isObject(DoorSO))
{
	new ScriptObject(DoorSO)
	{
		numDoors = 0;
	};
}

//Package

package jvsDoorsServer
{
	//Functions

	function changeMap(%path)
	{
		if(isObject(DoorListSO))
		{
			for(%i = 1;%i <= DoorListSO.getCount();%i++)
			{
				DoorListSO.Door[%i] = "";
			}

			DoorListSO.numDoors = 0;
		}
		else
		{
			error("JVS_Doors: DoorListSO does not exist!");
		}

		Parent::changeMap(%path);
	}

	function disconnect(%a)
	{
		Parent::disconnect(%a);

		if(isObject(DoorListSO))
		{
			DoorListSO.schedule(1000,"delete");
		}

		if(isObject(DoorSO))
		{
			DoorSO.schedule(1000,"delete");
		}

		schedule(1000, 0, "deactivatePackage", "jvsDoorsServer");
	}

	function doorEulerToAxis(%euler)
	{
		%euler = VectorScale(%euler,$pi / 180);
		%matrix = MatrixCreateFromEuler(%euler);
		return getWords(%matrix,3,6);
	}

	function onExit()
	{
		echo("Exporting JVS::Doors Prefs");
   		export("$JVS::Doors::*", "config/server/JVS/Doors/prefs.cs", False);
		Parent::onExit();
	}

	function returnMaxDoors()
	{
		if($JVS::Doors::MaxDoorsPerClient $= "" || $JVS::Doors::MaxDoorsPerClient < 0)
		{
			$JVS::Doors::MaxDoorsPerClient = 25;
		}

		return $JVS::Doors::MaxDoorsPerClient;
	}

	//DoorSO Methods

	function DoorSO::addDoorTypeFromFile(%this,%file)
	{
		deleteVariables("$JVS::Types::*");
		%filePath = filePath(%file);
		%typesCheck = getSubStr(%filePath,strLen(%filePath) - 6,6);

		if(isFile(%file) && %typesCheck $= "/types")
		{
			%basePath = getSubStr(%filePath,0,strLen(%filePath) - 5);
			%defaultPath = "Add-Ons/JVS_Doors/";
			%name = fileBase(%file);
			exec(%file);
			%parse = 1;

			if($JVS::Types::doorAnimationNameCloseCW $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationNameCloseCW is missing.");
			}

			if($JVS::Types::doorAnimationNameCloseCCW $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationNameCloseCCW is missing.");
			}

			if($JVS::Types::doorAnimationNameOpenCW $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationNameOpenCW is missing.");
			}

			if($JVS::Types::doorAnimationNameOpenCCW $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationNameOpenCCW is missing.");
			}

			if($JVS::Types::doorAnimationLengthClose $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationLengthClose is missing.");
			}

			if($JVS::Types::doorAnimationLengthOpen $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorAnimationLengthOpen is missing.");
			}

			if($JVS::Types::doorDatablockBrick $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockBrick is missing.");
			}

			if($JVS::Types::doorDatablockDebris $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockDebris is missing.");
			}

			if($JVS::Types::doorDatablockProjectile $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockProjectile is missing.");
			}

			if($JVS::Types::doorDatablockExplosion $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockExplosion is missing.");
			}

			if($JVS::Types::doorDatablockShape $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockShape is missing.");
			}

			if($JVS::Types::doorDatablockShapeColliding $= "" && %parse == 1)
			{
				$JVS::Types::doorDatablockShapeColliding = $JVS::Types::doorDatablockShape;
			}

			if($JVS::Types::doorDatablockSoundClose $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockSoundClose is missing.");
			}

			if($JVS::Types::doorDatablockSoundOpen $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorDatablockSoundOpen is missing.");
			}

			if($JVS::Types::doorGroups $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorGroups is missing.");
			}

			for(%j = 0;%j < $JVS::Types::doorGroups;%j++)
			{
				if($JVS::Types::doorGroupColor[%j] $= "" && %parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorGroupColor" @ %j @ " is missing.");
				}

				if($JVS::Types::doorGroupName[%j] $= "" && %parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorGroupName" @ %j @ " is missing.");
				}
			}

			if($JVS::Types::doorName $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorName is missing.");
			}

			if($JVS::Types::doorSearches $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorSearches is missing.");
			}

			for(%j = 0;%j < $JVS::Types::doorSearches;%j++)
			{
				if($JVS::Types::doorSearchBox[%j] $= "" && %parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSearchBox" @ %j @ " is missing.");
				}

				if($JVS::Types::doorSearchPositionCCW[%j] $= "" && %parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSearchPositionCCW" @ %j @ " is missing.");
				}

				if($JVS::Types::doorSearchPositionCW[%j] $= "" && %parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSearchPositionCW" @ %j @ " is missing.");
				}
			}

			if($JVS::Types::doorSize $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorSize is missing.");
			}
			else if(%parse == 1)
			{
				$JVS::Types::doorSizeX = mFloatLength(getField($JVS::Types::doorSize,0),0);
				$JVS::Types::doorSizeY = mFloatLength(getField($JVS::Types::doorSize,1),0);
				$JVS::Types::doorSizeZ = mFloatLength(getField($JVS::Types::doorSize,2),0);

				if($JVS::Types::doorSizeX > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSizeX is missing.");
				}

				if($JVS::Types::doorSizeY > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSizeY is missing.");
				}

				if($JVS::Types::doorSizeZ > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error(%name @ ": doorSizeZ is missing.");
				}
			}

			if($JVS::Types::doorSoundDelayClose $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorSoundDelayClose is missing.");
			}

			if($JVS::Types::doorSoundDelayOpen $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorSoundDelayOpen is missing.");
			}

			if($JVS::Types::doorSubCategory $= "" && %parse == 1)
			{
				%parse = 0;
				error(%name @ ": doorSubCategory is missing.");
			}

			if(!isFile(%basePath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb" @ " is missing.");
					}
					else
					{
						%brickFile = %defaultPath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb";
					}
				}
				else
				{
					error(%name @ ": " @ %basePath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb" @ " is missing.");
				}
			}
			else
			{
				%brickFile = %basePath @ "bricks/doorBLB_" @ $JVS::Types::doorSizeX @ "_" @ $JVS::Types::doorSizeY @ "_" @ $JVS::Types::doorSizeZ @ ".blb";
			}

			if(!isFile(%basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav" @ " is missing.");
					}
					else
					{
						%closeSoundFile = %defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav";
					}
				}
				else
				{
					%parse = 0;
					error(%name @ ": " @ %basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav" @ " is missing.");
				}
			}
			else
			{
				%closeSoundFile = %basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundClose @ ".wav";
			}

			if(!isFile(%basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav" @ " is missing.");
					}
					else
					{
						%openSoundFile = %defaultPath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav";
					}
				}
				else
				{
					%parse = 0;
					error(%name @ ": " @ %basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav" @ " is missing.");
				}
			}
			else
			{
				%openSoundFile = %basePath @ "sounds/" @ $JVS::Types::doorDatablockSoundOpen @ ".wav";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts" @ " is missing.");
					}
					else
					{
						%shapeFile = %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts";
					}
				}
				else
				{
					%parse = 0;
					error(%name @ ": " @ %basePath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts" @ " is missing.");
				}
			}
			else
			{
				%shapeFile = %basePath @ "shapes/" @ $JVS::Types::doorDatablockShape @ ".dts";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts" @ " is missing.");
					}
					else
					{
						%shapeFileColliding = %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts";
					}
				}
				else
				{
					%parse = 0;
					error(%name @ ": " @ %basePath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts" @ " is missing.");
				}
			}
			else
			{
				%shapeFileColliding = %basePath @ "shapes/" @ $JVS::Types::doorDatablockShapeColliding @ ".dts";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts") && %parse == 1)
					{
						%parse = 0;
						error(%name @ ": " @ %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts" @ " is missing.");
					}
					else
					{
						%debrisFile = %defaultPath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts";
					}
				}
				else
				{
					%parse = 0;
					error(%name @ ": " @ %basePath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts" @ " is missing.");
				}
			}
			else
			{
				%debrisFile = %basePath @ "shapes/" @ $JVS::Types::doorDatablockDebris @ ".dts";
			}

			if(!isFile(%basePath @ "icons/" @ $JVS::Types::doorDatablockShape @ ".png") && %parse == 1)
			{
				if(%basePath !$= %defaultPath)
				{
					if(!isFile(%defaultPath @ "icons/" @ $JVS::Types::doorDatablockShape @ ".png") && %parse == 1)
					{
						error(%name @ ": " @ %defaultPath @ "icons/" @ $JVS::Types::doorDatablockShape @ ".png" @ " is missing.");
					}
					else
					{
						%uiFile = %defaultPath @ "icons/" @ $JVS::Types::doorDatablockShape;
					}
				}
				else
				{
					error(%name @ ": " @ %basePath @ "icons/" @ $JVS::Types::doorDatablockShape @ ".png" @ " is missing.");
				}
			}
			else
			{
				%uiFile = %basePath @ "icons/" @ $JVS::Types::doorDatablockShape;
			}

			if(%this.isNameUnique($JVS::Types::doorName) && %parse == 1)
			{
				%door = %this.numDoors;

				%this.doorAnimationNameCloseCW[%door] = $JVS::Types::doorAnimationNameCloseCW;
				%this.doorAnimationNameCloseCCW[%door] = $JVS::Types::doorAnimationNameCloseCCW;
				%this.doorAnimationLengthClose[%door] = $JVS::Types::doorAnimationLengthClose;
				%this.doorAnimationNameOpenCW[%door] = $JVS::Types::doorAnimationNameOpenCW;
				%this.doorAnimationNameOpenCCW[%door] = $JVS::Types::doorAnimationNameOpenCCW;
				%this.doorAnimationLengthOpen[%door] = $JVS::Types::doorAnimationLengthOpen;
				%this.doorSearches[%door] = $JVS::Types::doorSearches;

				for(%j = 0;%j < %this.doorSearches[%door];%j++)
				{
					%this.doorSearchBox[%j @ "_" @ %door] = $JVS::Types::doorSearchBox[%j];
					%this.doorSearchPositionCCW[%j @ "_" @ %door] = $JVS::Types::doorSearchPositionCCW[%j];
					%this.doorSearchPositionCW[%j @ "_" @ %door] = $JVS::Types::doorSearchPositionCW[%j];
				}

				%this.doorDatablockBrick[%door] = $JVS::Types::doorDatablockBrick;
				%this.doorGroups[%door] = $JVS::Types::doorGroups;

				for(%j = 0;%j < %this.doorGroups[%door];%j++)
				{
					%this.doorGroupColor[%j @ "_" @ %door] = $JVS::Types::doorGroupColor[%j];
					%this.doorGroupName[%j @ "_" @ %door] = $JVS::Types::doorGroupName[%j];
				}

				%this.doorDatablockDebris[%door] = $JVS::Types::doorDatablockDebris;
				%this.doorName[%door] = $JVS::Types::doorName;
				%this.doorDatablockExplosion[%door] = $JVS::Types::doorDatablockExplosion;
				%this.doorDatablockProjectile[%door] = $JVS::Types::doorDatablockProjectile;
				%this.doorDatablockShape[%door] = $JVS::Types::doorDatablockShape;
				%this.doorDatablockShapeColliding[%door] = $JVS::Types::doorDatablockShapeColliding;
				%this.doorSize[%door] = $JVS::Types::doorSizeX TAB $JVS::Types::doorSizeY TAB $JVS::Types::doorSizeZ;
				%this.doorSoundDelayClose[%door] = $JVS::Types::doorSoundDelayClose;
				%this.doorDatablockSoundClose[%door] = $JVS::Types::doorDatablockSoundClose;
				%this.doorSoundDelayOpen[%door] = $JVS::Types::doorSoundDelayOpen;
				%this.doorDatablockSoundOpen[%door] = $JVS::Types::doorDatablockSoundOpen;
				%this.doorSubCategory[%door] = $JVS::Types::doorSubCategory;

				%brick = %this.getDatablockBrickFromID(%door);
				%size = %this.getSizeFromID(%door);
				%x = getField(%size,0);
				%y = getField(%size,1);
				%z = getField(%size,2);
				%closeSound = %this.getDatablockSoundCloseFromID(%door);
				%openSound = %this.getDatablockSoundOpenFromID(%door);
				%shape = %this.getDatablockShapeFromID(%door);
				%shapeColliding = %this.getDatablockShapeCollidingFromID(%door);
				%uiName = %this.getNameFromID(%door);
				%debris = %this.getDatablockDebrisFromID(%door);
				%explosion = %this.getDatablockExplosionFromID(%door);
				%projectile = %this.getDatablockProjectileFromID(%door);
				%subCategory = %this.getSubCategoryFromID(%door);

				if(!isObject(%brick))
				{
					datablock fxDTSBrickData(doorBrick)
					{
						bottomArea = %x * %y;
						brickFile = %brickFile;
						brickSizeX = %x;
						brickSizeY = %y;
						brickSizeZ = %z;
						canCoverBottom = 1;
						canCoverEast = 1;
						canCoverNorth = 1;
						canCoverSouth = 1;
						canCoverTop = 1;
						canCoverWest = 1;
						category = $JVS::Doors::Category;
						eastArea = %y * %z;
						hasPrint = 0;
						iconName = %uiFile;
						indestructable = 0;
						northArea = %x * %z;
						southArea = %x * %z;
						subCategory = %subCategory;
						topArea = %x * %y;
						uiName = %uiName;
						westArea = %y * %z;
					};

					doorBrick.setName(%brick);
				}
				
				if(!isObject(%closeSound))
				{
					datablock AudioProfile(doorCloseSound)
					{
						filename = %closeSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					doorCloseSound.setName(%closeSound);
				}
				
				if(!isObject(%openSound))
				{
					datablock AudioProfile(doorOpenSound)
					{
						filename = %openSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					doorOpenSound.setName(%openSound);
				}

				if(!isObject(%shape))
				{
					datablock StaticShapeData(doorShape)
					{
						shapefile = %shapeFile;
					};

					doorShape.setName(%shape);
				}

				if(!isObject(%shapeColliding))
				{
					datablock StaticShapeData(doorShapeColliding)
					{
						shapefile = %shapeFileColliding;
					};

					doorShapeColliding.setName(%shapeColliding);
				}

				if(!isObject(%debris))
				{
					datablock DebrisData(doorDebris)
					{
						baseRadius = "1";
						bounceVariance = "0";
						className = "DebrisData";
						elasticity = "0.5";
						explodeOnMaxBounce = "0";
						fade = "1";
						friction = "0.2";
						gravModifier = "2";
						ignoreWater = "1";
						lifetime = "2";
						lifetimeVariance = "0";
						maxSpinSpeed = "200";
						minSpinSpeed = "-400";
						numBounces = "3";
						render2D = "0";
						shapeFile = %debrisFile;
						snapOnMaxBounce = "0";
						staticOnMaxBounce = "1";
						terminalVelocity = "0";
						useRadiusMass = "0";
						velocity = "0";
						velocityVariance = "0";
						emitters[0] = "doorEmitterDebris";
					};

					doorDebris.setName(%debris);
				}

				if(!isObject(%explosion))
				{
					datablock ExplosionData(doorExplosion)
					{
						className = "ExplosionData";
						Debris = %debris;
						debrisNum = "1";
						debrisNumVariance = "0";
						debrisPhiMax = "360";
						debrisPhiMin = "0";
						debrisThetaMax = "85";
						debrisThetaMin = "40";
						debrisVelocity = "14";
						debrisVelocityVariance = "3";
						delayMS = "0";
						delayVariance = "0";
						explosionScale = "1 1 1";
						faceViewer = "1";
						lifetimeMS = "150";
						lifetimeVariance = "0";
						offset = "0";
						particleDensity = "10";
						particleRadius = "1";
						playSpeed = "1";
						shakeCamera = "0";
						damageRadius = "0";
						impulseForce = "0";
						impulseRadius = "0";
						radiusDamage = "0";
					};

					doorExplosion.setName(%explosion);
				}

				if(!isObject(%projectile))
				{
					datablock ProjectileData(doorProjectile)
					{
						directDamage = 0;
						radiusDamage = 0;
						damageRadius = 0;
						explosion = %explosion;
						directDamageType = $DamageType::jeepExplosion;
						radiusDamageType = $DamageType::jeepExplosion;
						explodeOnDeath = 1;
						armingDelay = 0;
						lifetime = 10;
					};

					doorProjectile.setName(%projectile);
				}

				%this.numDoors++;
			}
			else if(%parse == 1)
			{
				error("DoorSO: addDoorTypeFromFile - '" @ $JVS::Types::doorName @ "' already exists.");
			}

			deleteVariables("$JVS::Types::*");
		}
		else
		{
			error("DoorSO: addDoorTypeFromFile - " @ %file @ " is missing.");
		}
	}

	function DoorSO::getAnimationLengthCloseFromID(%this,%ID)
	{
		if(%this.doorAnimationLengthClose[%ID] !$= "")
		{
			return %this.doorAnimationLengthClose[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getAnimationLengthOpenFromID(%this,%ID)
	{
		if(%this.doorAnimationLengthOpen[%ID] !$= "")
		{
			return %this.doorAnimationLengthOpen[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getAnimationNameCloseCCWFromID(%this,%ID)
	{
		if(%this.doorAnimationNameCloseCCW[%ID] !$= "")
		{
			return %this.doorAnimationNameCloseCCW[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getAnimationNameCloseCWFromID(%this,%ID)
	{
		if(%this.doorAnimationNameCloseCW[%ID] !$= "")
		{
			return %this.doorAnimationNameCloseCW[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getAnimationNameOpenCCWFromID(%this,%ID)
	{
		if(%this.doorAnimationNameOpenCCW[%ID] !$= "")
		{
			return %this.doorAnimationNameOpenCCW[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getAnimationNameOpenCWFromID(%this,%ID)
	{
		if(%this.doorAnimationNameOpenCW[%ID] !$= "")
		{
			return %this.doorAnimationNameOpenCW[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getCount(%this)
	{
		return %this.numDoors;
	}

	function DoorSO::getDatablockBrickFromID(%this,%ID)
	{
		if(%this.doorDatablockBrick[%ID] !$= "")
		{
			return %this.doorDatablockBrick[%ID];
		}
		else
		{
			return -1;
		}
	}
	function DoorSO::getDatablockDebrisFromID(%this,%ID)
	{
		if(%this.doorDatablockDebris[%ID] !$= "")
		{
			return %this.doorDatablockDebris[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockExplosionFromID(%this,%ID)
	{
		if(%this.doorDatablockExplosion[%ID] !$= "")
		{
			return %this.doorDatablockExplosion[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockProjectileFromID(%this,%ID)
	{
		if(%this.doorDatablockProjectile[%ID] !$= "")
		{
			return %this.doorDatablockProjectile[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockShapeFromID(%this,%ID)
	{
		if(%this.doorDatablockShape[%ID] !$= "")
		{
			return %this.doorDatablockShape[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockShapeCollidingFromID(%this,%ID)
	{
		if(%this.doorDatablockShapeColliding[%ID] !$= "")
		{
			return %this.doorDatablockShapeColliding[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockSoundCloseFromID(%this,%ID)
	{
		if(%this.doorDatablockSoundClose[%ID] !$= "")
		{
			return %this.doorDatablockSoundClose[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getDatablockSoundOpenFromID(%this,%ID)
	{
		if(%this.doorDatablockSoundOpen[%ID] !$= "")
		{
			return %this.doorDatablockSoundOpen[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getIDFromDatablockBrick(%this,%datablockBrick)
	{
		%ID = -1;

		for(%i = 0;%i < %this.getCount();%i++)
		{
			%data = %this.getDatablockBrickFromID(%i);

			if(stricmp(%data,%datablockBrick) == 0)
			{
				%ID = %i;
			}
		}

		return %ID;
	}

	function DoorSO::getNameFromID(%this,%ID)
	{
		if(%this.doorName[%ID] !$= "")
		{
			return %this.doorName[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSearchBoxesFromID(%this,%ID)
	{
		if(%this.getSearchesFromID(%ID) > 0)
		{
			for(%i = 0;%i < %this.getSearchesFromID(%ID);%i++)
			{
				if(%this.doorSearchBox[%i @ "_" @ %ID] !$= "")
				{
					if(%boxes $= "")
					{
						%boxes = %this.doorSearchBox[%i @ "_" @ %ID];
					}
					else
					{
						%boxes = %boxes TAB %this.doorSearchBox[%i @ "_" @ %ID];
					}
				}
				else
				{
					return -1;
				}
			}

			return %boxes;
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSearchesFromID(%this,%ID)
	{
		if(%this.doorSearches[%ID] !$= "")
		{
			return %this.doorSearches[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSearchPositionsCCWFromID(%this,%ID)
	{
		if(%this.getSearchesFromID(%ID) > -1)
		{
			for(%i = 0;%i < %this.getSearchesFromID(%ID);%i++)
			{
				if(%this.doorSearchPositionCCW[%i @ "_" @ %ID] !$= "")
				{
					if(%positions $= "")
					{
						%positions = %this.doorSearchPositionCCW[%i @ "_" @ %ID];
					}
					else
					{
						%positions = %positions TAB %this.doorSearchPositionCCW[%i @ "_" @ %ID];
					}
				}
				else
				{
					return -1;
				}
			}

			return %positions;
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSearchPositionsCWFromID(%this,%ID)
	{
		if(%this.getSearchesFromID(%ID) > -1)
		{
			for(%i = 0;%i < %this.getSearchesFromID(%ID);%i++)
			{
				if(%this.doorSearchPositionCW[%i @ "_" @ %ID] !$= "")
				{
					if(%positions $= "")
					{
						%positions = %this.doorSearchPositionCW[%i @ "_" @ %ID];
					}
					else
					{
						%positions = %positions TAB %this.doorSearchPositionCW[%i @ "_" @ %ID];
					}
				}
				else
				{
					return -1;
				}
			}

			return %positions;
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSizeFromID(%this,%ID)
	{
		if(%this.doorSize[%ID] !$= "")
		{
			return %this.doorSize[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSoundDelayCloseFromID(%this,%ID)
	{
		if(%this.doorSoundDelayClose[%ID] !$= "")
		{
			return %this.doorSoundDelayClose[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSoundDelayOpenFromID(%this,%ID)
	{
		if(%this.doorSoundDelayOpen[%ID] !$= "")
		{
			return %this.doorSoundDelayOpen[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::getSubCategoryFromID(%this,%ID)
	{
		if(%this.doorSubCategory[%ID] !$= "")
		{
			return %this.doorSubCategory[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorSO::isNameUnique(%this,%name)
	{
		%unique = 1;

		for(%i = 0;%i < %this.getCount();%i++)
		{
			if(stricmp(%this.doorName[%i],%name) == 0)
			{
				%unique = 0;
			}
		}

		return %unique;
	}

	//DoorListSO Methods

	function DoorListSO::add(%this,%obj)
	{
		if(isObject(%obj))
		{
			%exists = 0;

			for(%i = 1;%i <= %this.getCount();%i++)
			{
				if(%this.Door[%i] == %obj)
				{
					%exists = 1;
				}
			}

			if(%exists != 1)
			{
				%this.Door[%this.numDoors++] = %obj;
			}
		}
	}

	function DoorListSO::getCount(%this)
	{
		return %this.numDoors;
	}

	function DoorListSO::getDoorFromID(%this,%ID)
	{
		if(%this.Door[%ID] !$= "")
		{
			return %this.Door[%ID];
		}
		else
		{
			return -1;
		}
	}

	function DoorListSO::listObjects(%this)
	{
		for(%i = 1;%i <= %this.numDoors;%i++)
		{
			echo("   " @ %this.Door[%i] @ ": " @ %this.Door[%i].getClassName());
		}
	}

	function DoorListSO::remove(%this,%obj)
	{
		%doors = 0;

		for(%i = 1;%i <= %this.numDoors;%i++)
		{
			if(%this.Door[%i] != %obj)
			{
				%doors++;
				%door[%doors] = %this.Door[%i];
			}

			%this.Door[%i] = "";
		}

		if(%doors > 0)
		{
			for(%j = 1;%j <= %doors;%j++)
			{
				%this.Door[%j] = %door[%j];
			}

			%this.numDoors = %doors;
		}
		else
		{
			%this.numDoors = 0;
		}
	}

	//fxDTSBrick Methods

	function fxDTSBrick::doorAdminCloseCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%client.isAdmin || %client.isSuperAdmin)
			{
				%obj.doorCloseCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorAdminCloseCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%client.isAdmin || %client.isSuperAdmin)
			{
				%obj.doorCloseCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorAdminOpenCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%client.isAdmin || %client.isSuperAdmin)
			{
				%obj.doorOpenCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorAdminOpenCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%client.isAdmin || %client.isSuperAdmin)
			{
				%obj.doorOpenCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDAllowCloseCCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%allow = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%allow = 1;
						break;
					}
				}

				if(%allow == 1)
				{
					%obj.doorCloseCCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDAllowCloseCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%allow = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%allow = 1;
						break;
					}
				}

				if(%allow == 1)
				{
					%obj.doorCloseCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDAllowOpenCCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%allow = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%allow = 1;
						break;
					}
				}

				if(%allow == 1)
				{
					%obj.doorOpenCCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDAllowOpenCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%allow = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%allow = 1;
						break;
					}
				}

				if(%allow == 1)
				{
					%obj.doorOpenCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDDenyCloseCCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%deny = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%deny = 1;
						break;
					}
				}

				if(%deny == 0)
				{
					%obj.doorCloseCCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.doorCloseCCW(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDDenyCloseCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%deny = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%deny = 1;
						break;
					}
				}

				if(%deny == 0)
				{
					%obj.doorCloseCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.doorCloseCW(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDDenyOpenCCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%deny = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%deny = 1;
						break;
					}
				}

				if(%deny == 0)
				{
					%obj.doorOpenCCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.doorOpenCCW(%client);
			}
		}
	}

	function fxDTSBrick::doorBLIDDenyOpenCW(%obj,%blidList,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%blidList !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%blidList);%i++)
				{
					%word = getWord(%blidList,%i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word,%j,1);

						if(strstr("1234567890",%char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%deny = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%deny = 1;
						break;
					}
				}

				if(%deny == 0)
				{
					%obj.doorOpenCW(%client);
				}
				else
				{
					%obj.onDoorRestricted(%client);
				}
			}
			else
			{
				%obj.doorOpenCW(%client);
			}
		}
	}

	function fxDTSBrick::doorBrickSetProperties(%obj,%colliding,%raycasting,%rendering)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%colliding == 0 || %colliding == 1)
			{
				%obj.setColliding(%colliding);
			}

			if(%raycasting == 0 || %raycasting == 1)
			{
				%obj.setRaycasting(%raycasting);
			}

			if(%rendering == 0 || %rendering == 1)
			{
				%obj.setRendering(%rendering);
			}
		}
	}

	function fxDTSBrick::doorCheck(%obj)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(!isObject(%obj.Door) || %obj.Door.scale !$= "1 1 1" || %obj.Door.getTransform() !$= %obj.Door.transform)
			{
				%owner = %obj.getGroup().client;

				for(%i = 1;%i <= DoorListSO.getCount();%i++)
				{
					%brick = DoorListSO.getDoorFromID(%i);

					if(isObject(%brick) && %brick.getGroup().client == %owner && !%brick.isDead() && %brick != %obj)
					{
						%doors++;
					}
				}

				%max = returnMaxDoors();

				if(%doors < %max)
				{
					%obj.doorCreate(%obj.getGroup().client,0,0,1);
				}
			}
		}
	}

	function fxDTSBrick::doorClose(%obj,%closeType,%textEntry,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			%obj.doorCheck();

			switch(%closeType)
			{
				case 0:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorCloseCCW(%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorCloseCW(%client);
					}

				case 1:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorAdminCloseCCW(%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorAdminCloseCW(%client);
					}

				case 2:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorBLIDAllowCloseCCW(%textEntry,%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorBLIDAllowCloseCW(%textEntry,%client);
					}

				case 3:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorBLIDDenyCloseCCW(%textEntry,%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorBLIDDenyCloseCW(%textEntry,%client);
					}

				case 4:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorMiniGameCloseCCW(%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorMiniGameCloseCW(%client);
					}

				case 5:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorTrustLevel1CloseCCW(%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorTrustLevel1CloseCW(%client);
					}

				case 6:

					if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
					{
						%obj.doorTrustLevel1CloseCCW(%client);
					}
					else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
					{
						%obj.doorTrustLevel1CloseCW(%client);
					}
			}
		}
	}

	function fxDTSBrick::doorCloseCCW(%obj,%client,%no_buzzer)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door) && %obj.Door.closed == 0 && %obj.Door.closing == 0 && %obj.Door.open == 1 && %obj.Door.opening == 0)
		{
			%blockage = %obj.isDoorBlockedCCW(%client,%no_buzzer);

			if(%blockage != 1)
			{
				%obj.onDoorClose(%client);
				%obj.Door.closeAnimationName = "";
				%obj.doorBrickSetProperties(-1,-1,0);
				%time = DoorSO.getAnimationLengthCloseFromID(%doorID);
				%obj.Door.unhideNode("ALL");
				%obj.Door.playThread(0,DoorSO.getAnimationNameCloseCCWFromID(%doorID));
				%obj.schedule(%time,"doorStateClosingToClosed",%client);
				%obj.Door.closed = 0;
				%obj.Door.closing = 1;
				%obj.Door.open = 0;
				%obj.Door.opening = 0;
			}
			else
			{
				%obj.onDoorCloseCheck(%client);
			}
		}
	}

	function fxDTSBrick::doorCloseCheck(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCCWFromID(%doorID))
			{
				%obj.doorCloseCCW(%client,1);
			}
			else if(%obj.Door.closeAnimationName $= DoorSO.getAnimationNameCloseCWFromID(%doorID))
			{
				%obj.doorCloseCW(%client,1);
			}
		}
	}

	function fxDTSBrick::doorCloseCW(%obj,%client,%no_buzzer)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door) && %obj.Door.closed == 0 && %obj.Door.closing == 0 && %obj.Door.open == 1 && %obj.Door.opening == 0)
		{
			%blockage = %obj.isDoorBlockedCW(%client,%no_buzzer);

			if(%blockage != 1)
			{
				%obj.onDoorClose(%client);
				%obj.Door.closeAnimationName = "";
				%obj.doorBrickSetProperties(-1,-1,0);
				%time = DoorSO.getAnimationLengthCloseFromID(%doorID);
				%obj.Door.unhideNode("ALL");
				%obj.Door.playThread(0,DoorSO.getAnimationNameCloseCWFromID(%doorID));
				%obj.schedule(%time,"doorStateClosingToClosed",%client);
				%obj.Door.closed = 0;
				%obj.Door.closing = 1;
				%obj.Door.open = 0;
				%obj.Door.opening = 0;
			}
			else
			{
				%obj.onDoorCloseCheck(%client);
			}
		}
	}

	function fxDTSBrick::doorCreate(%obj,%client,%isPlantedBrick,%isLoadedBrick,%allowLimitOverride)
	{
		%owner = %obj.getGroup().client;
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj))
		{
			if(isObject(%obj.Door))
			{
				%obj.Door.delete();
			}

			%doors = 0;

			for(%i = 1;%i <= DoorListSO.getCount();%i++)
			{
				%brick = DoorListSO.getDoorFromID(%i);

				if(isObject(%brick) && %brick.getGroup().client == %owner && !%brick.isDead() && %brick != %obj)
				{
					%doors++;
				}
			}

			%max = returnMaxDoors();

			if(%doors < %max || %allowLimitOverride == 1)
			{
				%angleID = %obj.getAngleID();
				%datablock = DoorSO.getDatablockShapeCollidingFromID(%doorID);

				%door = new StaticShape()
				{
					datablock = %datablock;
					spawnBrick = %obj;
				};

				if(isObject(%door))
				{
					MissionCleanup.add(%door);
					%obj.Door = %door;
					%door.closed = 1;
					%door.closing = 0;
					%door.open = 0;
					%door.opening = 0;

					%color = getColorIDTable(%obj.getColorId());
					%r = getWord(%color,0);
					%g = getWord(%color,1);
					%b = getWord(%color,2);
					%color1 = %r SPC %g SPC %b SPC 1;
					%color2 = %r * 0.75 SPC %g * 0.75 SPC %b * 0.75 SPC 1;

					for(%i = 0;%i < DoorSO.doorGroups[%doorID];%i++)
					{
						%color = DoorSO.doorGroupColor[%i @ "_" @ %doorID];
						%group = DoorSO.doorGroupName[%i @ "_" @ %doorID];

						if(%color $= "color1")
						{
							%door.setNodeColor(%group,%color1);
						}
						else if(%color $= "color2")
						{
							%door.setNodeColor(%group,%color2);
						}
						else
						{
							%door.setNodeColor(%group,%color);
						}
					}

					%pos = %obj.position;

					if(%angleID == 2)
					{
						%door.setTransform(%pos SPC doorEulerToAxis("0 0 270"));
					}
					else if(%angleID == 0)
					{
						%door.setTransform(%pos SPC doorEulerToAxis("0 0 90"));
					}
					else if(%angleID == 1)
					{
						%door.setTransform(%pos SPC doorEulerToAxis("0 0 0"));
					}
					else if(%angleID == 3)
					{
						%door.setTransform(%pos SPC doorEulerToAxis("0 0 180"));
					}

					%door.transform = %door.getTransform();

					if(%isLoadedBrick != 1)
					{
						%obj.schedule(25,"doorBrickSetProperties",1,1,0);
					}

					if(%isPlantedBrick == 1 && %isLoadedBrick != 1 && %obj.noDefaultDoorEvents != 1)
					{
						%obj.clearEvents();
						%oldWrenchBrick = %owner.wrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onActivate";
						%targetName = "Self";
						%outputEventName = "doorOpen";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,0,0);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 3000;
						%inputEventName = "onDoorOpened";
						%targetName = "Self";
						%outputEventName = "doorClose";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,0);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorRestricted";
						%targetName = "Client";
						%outputEventName = "CenterPrint";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,"You are not permitted to operate this Door.",2);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorRestricted";
						%targetName = "Self";
						%outputEventName = "playSound";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx, "doorBuzzerSound");
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorBlocked";
						%targetName = "Client";
						%outputEventName = "CenterPrint";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,"At least one brick and / or vehicle blocks the path through this Door.",2);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorBlocked";
						%targetName = "Self";
						%outputEventName = "playSound";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,"doorBuzzerSound");
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 200;
						%inputEventName = "onDoorCloseCheck";
						%targetName = "Self";
						%outputEventName = "doorCloseCheck";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = DoorSO.getSoundDelayOpenFromID(%doorID);
						%inputEventName = "onDoorOpen";
						%targetName = "Self";
						%outputEventName = "playSound";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,DoorSO.getDatablockSoundOpenFromID(%doorID));
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = DoorSO.getSoundDelayCloseFromID(%doorID);
						%inputEventName = "onDoorClose";
						%targetName = "Self";
						%outputEventName = "playSound";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,DoorSO.getDatablockSoundCloseFromID(%doorID));
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorStuckPlayer";
						%targetName = "Self";
						%outputEventName = "doorOpen";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,0,0);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorStuckVehicle";
						%targetName = "StuckVehicleSpawns";
						%outputEventName = "respawnVehicle";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,0,0);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onBlownUp";
						%targetName = "Self";
						%outputEventName = "doorDestroy";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorRestore";
						%targetName = "Self";
						%outputEventName = "setRendering";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,1);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 600;
						%inputEventName = "onDoorRestore";
						%targetName = "Self";
						%outputEventName = "doorCreate";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorLoaded";
						%targetName = "Self";
						%outputEventName = "setColliding";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,1);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorLoaded";
						%targetName = "Self";
						%outputEventName = "setRaycasting";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,1);
						%owner.wrenchBrick = %oldWrenchBrick;

						%enabled = true;
						%delay = 0;
						%inputEventName = "onDoorLoaded";
						%targetName = "Self";
						%outputEventName = "setRendering";
						%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
						%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick",%inputEventIdx,%targetName);
						%targetClass = inputEvent_GetTargetClass("fxDTSBrick",%inputEventIdx,%targetIdx);
						%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass,%outputEventName);
						%NamedTargetNameIdx = -1;
						%owner.wrenchBrick = %obj;
						serverCmdAddEvent(%owner,%enabled,%inputEventIdx,%delay,%targetIdx,%NamedTargetNameIdx,%outputEventIdx,0);
						%owner.wrenchBrick = %oldWrenchBrick;
					}
					else if(%obj.noDefaultDoorEvents == 1)
					{
						%obj.noDefaultDoorEvents = "";
					}
				}
			}
			else
			{
				%obj.schedule(25,"doorBrickSetProperties",0,0,0);

				if(isObject(%client) && %isLoadedBrick != 1)
				{
					if(%max > 1)
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make more than " @ %max @ " Doors.",2,2,2000);
					}
					else if(%max == 1)
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make more than " @ %max @ " Door.",2,2,2000);
					}
					else
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make Doors.",2,2,2000);
					}
				}
			}

			DoorListSO.add(%obj);

			if(%isLoadedBrick == 1)
			{
				%obj.onDoorLoaded(%client);
			}
		}
	}

	function fxDTSBrick::doorDestroy(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%obj.isFakeDead() != 1)
			{
				%obj.fakeKillBrick();
			}

			if(isObject(%obj.Door))
			{
				%obj.Door.delete();
			}

			%obj.doorBrickSetProperties(0,0,0);

            %p = new Projectile()
            {
				dataBlock = DoorSO.getDatablockProjectileFromID(%doorID);
				initialPosition = %obj.getPosition();
				initialVelocity = "0 0 1";
				client = %client;
				sourceClient = %client;
            };
		}
	}

	function fxDTSBrick::doorGhostCheck(%obj)
	{
		if(isObject(%obj) && !%obj.isPlanted)
		{
			%error = 0;
			%doorID = -1;

			if(!isObject(DoorSO))
			{
				%error = 1;
				error("JVS_Doors: DoorSO does not exist!");
			}

			if(!isObject(DoorListSO))
			{
				%error = 1;
				error("JVS_Doors: DoorListSO does not exist!");
			}

			if(%error != 1)
			{
				%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
			}
			else
			{
				error("JVS_Doors: De-activating package.");
				deactivatePackage(jvsDoorsServer);
			}

			if(%doorID > -1)
			{
				if(isObject(%obj.ghostDoor) && %obj.dataBlock $= DoorSO.getDatablockShapeFromID(%doorID))
				{
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = doorEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = doorEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = doorEulerToAxis("0 0 90");
					}
					else
					{
						%rot = doorEulerToAxis("0 0 0");
					}

					%obj.ghostDoor.setTransform(%pos SPC %rot);
				}
				else
				{
					if(isObject(%obj.ghostDoor))
					{
						%obj.ghostDoor.delete();
					}

					%obj.ghostDoor = "";
					%client = %obj.getGroup().client;
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = doorEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = doorEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = doorEulerToAxis("0 0 90");
					}
					else
					{
						%rot = doorEulerToAxis("0 0 0");
					}

					%dataBlock = DoorSO.getDatablockShapeFromID(%doorID);

					%obj.ghostDoor = new StaticShape()
					{
						dataBlock = %dataBlock;
					};

					%obj.ghostDoor.setTransform(%pos SPC %rot);
					%color = %obj.getColorId();
					%setcolor = getColorIDTable(%color);
					%r = getWord(%setcolor,0);
					%g = getWord(%setcolor,1);
					%b = getWord(%setcolor,2);
					%obj.ghostDoor.setNodeColor("ALL",%r SPC %g SPC %b SPC 1);
				}
			}
			else
			{
				if(isObject(%obj.ghostDoor))
				{
					%obj.ghostDoor.delete();
				}
				
				%obj.ghostDoor = "";
			}
		}
		else if(isObject(%obj) && %obj.isPlanted)
		{
			if(isObject(%obj.ghostDoor))
			{
				%obj.ghostDoor.delete();
			}

			%obj.ghostDoor = "";
		}
	}

	function fxDTSBrick::doorHide(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door) && %obj.Door.closed == 1)
		{
			%obj.Door.hideNode("ALL");
		}
	}

	function fxDTSBrick::doorMiniGameCloseCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(miniGameCanUse(%client,%obj) == 1)
			{
				%obj.doorCloseCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorMiniGameCloseCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(miniGameCanUse(%client,%obj) == 1)
			{
				%obj.doorCloseCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorMiniGameOpenCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(miniGameCanUse(%client,%obj) == 1)
			{
				%obj.doorOpenCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorMiniGameOpenCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(miniGameCanUse(%client,%obj) == 1)
			{
				%obj.doorOpenCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorOpen(%obj,%openType,%openDir,%textEntry,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			%obj.doorCheck();

			switch(%openType)
			{
				case 0:

					switch(%openDir)
					{
						case 0:

							%obj.doorOpenCW(%client);
						case 1:

							%obj.doorOpenCCW(%client);
					}

				case 1:

					switch(%openDir)
					{
						case 0:

							%obj.doorAdminOpenCW(%client);

						case 1:

							%obj.doorAdminOpenCCW(%client);
					}

				case 2:

					switch(%openDir)
					{
						case 0:

							%obj.doorBLIDAllowOpenCW(%textEntry,%client);

						case 1:

							%obj.doorBLIDAllowOpenCCW(%textEntry,%client);
					}

				case 3:

					switch(%openDir)
					{
						case 0:

							%obj.doorBLIDDenyOpenCW(%textEntry,%client);

						case 1:

							%obj.doorBLIDDenyOpenCCW(%textEntry,%client);
					}

				case 4:

					switch(%openDir)
					{
						case 0:

							%obj.doorMiniGameOpenCW(%client);

						case 1:

							%obj.doorMiniGameOpenCCW(%client);
					}

				case 5:

					switch(%openDir)
					{
						case 0:

							%obj.doorTrustLevel1OpenCW(%client);

						case 1:

							%obj.doorTrustLevel1OpenCCW(%client);
					}

				case 6:

					switch(%openDir)
					{
						case 0:

							%obj.doorTrustLevel2OpenCW(%client);

						case 1:

							%obj.doorTrustLevel2OpenCCW(%client);
					}
				
			}
		}
	}

	function fxDTSBrick::doorOpenCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		%blockage = %obj.isDoorBlockedCCW(%client);

		if(%doorID > -1 && isObject(%obj.Door) && %obj.Door.closed == 1 && %obj.Door.closing == 0 && %obj.Door.open == 0 && %obj.Door.opening == 0)
		{
			if(%blockage != 1)
			{
				%obj.onDoorOpen(%client);
				%obj.doorBrickSetProperties(0,0,0);
				%obj.Door.closeAnimationName = DoorSO.getAnimationNameCloseCCWFromID(%doorID);
				%obj.Door.unhideNode("ALL");
				%obj.Door.playThread(0,DoorSO.getAnimationNameOpenCCWFromID(%doorID));
				%time = DoorSO.getAnimationLengthOpenFromID(%doorID);
				%obj.schedule(%time,"doorStateOpeningToOpened",%client);
				%obj.Door.closed = 0;
				%obj.Door.closing = 0;
				%obj.Door.open = 0;
				%obj.Door.opening = 1;
			}
		}
	}

	function fxDTSBrick::doorOpenCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		%blockage = %obj.isDoorBlockedCW(%client);

		if(%doorID > -1 && isObject(%obj.Door) && %obj.Door.closed == 1 && %obj.Door.closing == 0 && %obj.Door.open == 0 && %obj.Door.opening == 0)
		{
			if(%blockage != 1)
			{
				%obj.onDoorOpen(%client);
				%obj.doorBrickSetProperties(0,0,0);
				%obj.Door.closeAnimationName = DoorSO.getAnimationNameCloseCWFromID(%doorID);
				%obj.Door.unhideNode("ALL");
				%obj.Door.playThread(0,DoorSO.getAnimationNameOpenCWFromID(%doorID));
				%time = DoorSO.getAnimationLengthOpenFromID(%doorID);
				%obj.schedule(%time,"doorStateOpeningToOpened",%client);
				%obj.Door.closed = 0;
				%obj.Door.closing = 0;
				%obj.Door.open = 0;
				%obj.Door.opening = 1;
			}
		}
	}

	function fxDTSBrick::doorStateClosingToClosed(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door))
		{
			%obj.doorBrickSetProperties(1,1,-1);
			%obj.Door.closed = 1;
			%obj.onDoorClosed(%client);
			%obj.Door.closing = 0;
			%obj.Door.open = 0;
			%obj.Door.opening = 0;
			%obj.Door.closeAnimationName = "";
			%obj.Door.closeAnimationTime = "";
			%obj.isDoorPlayerStuck(%client);
		}
	}

	function fxDTSBrick::doorStateOpeningToOpened(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door))
		{
			%obj.Door.closed = 0;
			%obj.Door.closing = 0;
			%obj.Door.open = 1;
			%obj.onDoorOpened(%client);
			%obj.Door.opening = 0;
		}
	}

	function fxDTSBrick::doorTrustLevel1CloseCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) >= 1)
			{
				%obj.doorCloseCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel1CloseCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) >= 1)
			{
				%obj.doorCloseCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel1OpenCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) >= 1)
			{
				%obj.doorOpenCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel1OpenCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) >= 1)
			{
				%obj.doorOpenCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel2CloseCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) == 2)
			{
				%obj.doorCloseCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel2CloseCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) == 2)
			{
				%obj.doorCloseCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel2OpenCCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) == 2)
			{
				%obj.doorOpenCCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::doorTrustLevel2OpenCW(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(getTrustLevel(%client,%obj) == 2)
			{
				%obj.doorOpenCW(%client);
			}
			else
			{
				%obj.onDoorRestricted(%client);
			}
		}
	}

	function fxDTSBrick::fakeKillBrick(%obj, %velocity_vector, %seconds_until_respawn, %client)
	{
		Parent::fakeKillBrick(%obj, %velocity_vector, %seconds_until_respawn, %client);

		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			%obj.doorDestroy();
		}
	}

	function fxDTSBrick::isDoorBlockedCCW(%obj,%client,%no_buzzer)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door))
		{
			%door = %obj.Door;
			%boxes = DoorSO.getSearchBoxesFromID(%doorID);
			%positions = DoorSO.getSearchPositionsCCWFromID(%doorID);
			%objects = 0;

			if(getFieldCount(%boxes) > 0 && getFieldCount(%boxes) == getFieldCount(%positions))
			{
				for(%i = 0;%i < getFieldCount(%boxes);%i++)
				{
					%boxX = getWord(getField(%boxes,%i),0);
					%boxY = getWord(getField(%boxes,%i),1);
					%boxZ = getWord(getField(%boxes,%i),2);

					%posX = getWord(getField(%positions,%i),0);
					%posY = getWord(getField(%positions,%i),1);
					%posZ = getWord(getField(%positions,%i),2);

					%brickX = getWord(%obj.position,0);
					%brickY = getWord(%obj.position,1);
					%brickZ = getWord(%obj.position,2);

					if(%obj.getAngleID() == 1)
					{
						%pos = %brickX + %posX SPC %brickY + %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 2)
					{
						%pos = %brickX + %posY SPC %brickY + %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else if(%obj.getAngleID() == 3)
					{
						%pos = %brickX - %posX SPC %brickY - %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 0)
					{
						%pos = %brickX - %posY SPC %brickY - %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else
					{
						return -1;
					}

					InitContainerBoxSearch(%pos, %box, $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::VehicleObjectType);

					while(isObject(%checkObj = containerSearchNext()))
					{
						if(%checkObj.getClassName() !$= "fxDTSBrick" || (%checkObj != %obj && %checkObj.isPlanted == 1 && !%checkObj.isFakeDead() && !%checkObj.isDead() && (%checkObj.isColliding() || DoorSO.getIDFromDatablockBrick(%checkObj.dataBlock) > -1)))
						{
							%objects++;
						}
					}

				}

				if(%objects > 0)
				{
					if(isObject(%client) && %no_buzzer != 1)
					{
						%obj.onDoorBlocked(%client);
					}

					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return -1;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::isDoorBlockedCW(%obj,%client,%no_buzzer)
	{

		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door))
		{
			%door = %obj.Door;
			%boxes = DoorSO.getSearchBoxesFromID(%doorID);
			%positions = DoorSO.getSearchPositionsCWFromID(%doorID);
			%objects = 0;

			if(getFieldCount(%boxes) > 0 && getFieldCount(%boxes) == getFieldCount(%positions))
			{
				for(%i = 0;%i < getFieldCount(%boxes);%i++)
				{
					%boxX = getWord(getField(%boxes,%i),0);
					%boxY = getWord(getField(%boxes,%i),1);
					%boxZ = getWord(getField(%boxes,%i),2);

					%posX = getWord(getField(%positions,%i),0);
					%posY = getWord(getField(%positions,%i),1);
					%posZ = getWord(getField(%positions,%i),2);

					%brickX = getWord(%obj.position,0);
					%brickY = getWord(%obj.position,1);
					%brickZ = getWord(%obj.position,2);

					if(%obj.getAngleID() == 1)
					{
						%pos = %brickX + %posX SPC %brickY + %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 2)
					{
						%pos = %brickX + %posY SPC %brickY + %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else if(%obj.getAngleID() == 3)
					{
						%pos = %brickX - %posX SPC %brickY - %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 0)
					{
						%pos = %brickX - %posY SPC %brickY - %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else
					{
						return -1;
					}

					InitContainerBoxSearch(%pos, %box, $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::VehicleObjectType);

					while(isObject(%checkObj = containerSearchNext()))
					{
						if(%checkObj.getClassName() !$= "fxDTSBrick" || (%checkObj != %obj && %checkObj.isPlanted == 1 && !%checkObj.isFakeDead() && !%checkObj.isDead() && (%checkObj.isColliding() || DoorSO.getIDFromDatablockBrick(%checkObj.dataBlock) > -1)))
						{
							%objects++;
						}
					}
				}

				if(%objects > 0)
				{
					if(isObject(%client) && %no_buzzer != 1)
					{
						%obj.onDoorBlocked(%client);
					}

					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return -1;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::isDoorPlayerStuck(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1 && isObject(%obj.Door))
		{
			%size = DoorSO.getSizeFromID(%doorID);
			%x = getField(%size,0);
			%y = getField(%size,1);
			%z = getField(%size,2);
			%box = %x / 2 - 0.1 SPC %y / 2 - 0.1 SPC %z / 3 * 0.6 - 0.1;
			%pos = %obj.position;
			%objects = 0;
			InitContainerBoxSearch(%pos,%box,$TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType);

			while(isObject(%checkObj = containerSearchNext()))
			{
				if(%checkObj.getClassName() $= "Player")
				{
					if(%checkObj.isEnabled())
					{
						if(%checkObj.isCrouched())
						{
							%boxMax = vectorAdd(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().crouchBoundingBox, 1/8));
							%boxMin = vectorSub(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().crouchBoundingBox, 1/8));
						}
						else
						{
							%boxMax = vectorAdd(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().boundingBox, 1/8));
							%boxMin = vectorSub(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().boundingBox, 1/8));
						}

						%brickMinX = getWord(%obj.getWorldBox(),0);
						%brickMinY = getWord(%obj.getWorldBox(),1);
						%brickMinZ = getWord(%obj.getWorldBox(),2);

						%brickMaxX = getWord(%obj.getWorldBox(),3);
						%brickMaxY = getWord(%obj.getWorldBox(),4);
						%brickMaxZ = getWord(%obj.getWorldBox(),5);

						%playerMinX = getWord(%boxMin,0);
						%playerMinY = getWord(%boxMin,1);
						%playerMinZ = getWord(%boxMin,2);

						%playerMaxX = getWord(%boxMax,0);
						%playerMaxY = getWord(%boxMax,1);
						%playerMaxZ = getWord(%boxMax,2);

						if(%playerMaxX > %brickMinX && %playerMinX < %brickMaxX && %playerMaxY > %brickMinY && %playerMinY < %brickMaxY && %playerMaxZ > %brickMinZ && %playerMinZ < %brickMaxZ)
						{
							%objects++;
							%obj.onDoorStuckPlayer(%client,%checkObj);
						}
					}
				}
				else
				{
					%objects++;
					%obj.onDoorStuckVehicle(%client,%checkObj);
				}
			}

			if(%objects > 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::onClearFakeDeath(%obj)
	{
		Parent::onClearFakeDeath(%obj);
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(%obj.destroyingClient)
			{
				%obj.onDoorRestore(%obj.destroyingClient);
			}
			else
			{
				%obj.onDoorRestore(%obj.getGroup().client,0,0,1);
			}
		}
	}

	function fxDTSBrick::onDeath(%obj)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(isObject(%obj.Door))
			{
				%obj.Door.delete();
			}

			%obj.Door = "";
		}

		Parent::onDeath(%obj);
	}

	function fxDTSBrick::onDoorBlocked(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorBlocked",%client);
		}
	}

	function fxDTSBrick::onDoorClose(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorClose",%client);
		}
	}

	function fxDTSBrick::onDoorCloseCheck(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorCloseCheck",%client);
		}
	}

	function fxDTSBrick::onDoorClosed(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorClosed",%client);
		}
	}

	function fxDTSBrick::onDoorClose(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorClose",%client);
		}
	}

	function fxDTSBrick::onDoorLoaded(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorLoaded",%client);
		}
	}

	function fxDTSBrick::onDoorOpen(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorOpen",%client);
		}
	}

	function fxDTSBrick::onDoorOpened(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorOpened",%client);
		}
	}

	function fxDTSBrick::onDoorRestore(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorRestore",%client);
		}
	}

	function fxDTSBrick::onDoorRestricted(%obj,%client)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			%obj.processInputEvent("onDoorRestricted",%client);
		}
	}

	function fxDTSBrick::onDoorStuckPlayer(%obj,%client,%stuckPlayer)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			$InputTarget_["StuckClients"] = %stuckPlayer.client;
			$InputTarget_["StuckPlayers"] = %stuckPlayer;
			%obj.processInputEvent("onDoorStuckPlayer",%client);
		}
	}

	function fxDTSBrick::onDoorStuckVehicle(%obj,%client,%stuckVehicle)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}
			}

			if(isObject(%stuckVehicle.spawnBrick))
			{
				$InputTarget_["StuckVehicleSpawns"] = %stuckVehicle.spawnBrick;
			}
			else
			{
				$InputTarget_["StuckVehicleSpawns"] = 0;
			}

			%obj.processInputEvent("onDoorStuckVehicle",%client);
		}
	}

	function fxDTSBrick::onPlant(%obj)
	{
		Parent::onPlant(%obj);
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			%client = %obj.getGroup().client;

			if(%obj == $LastLoadedBrick)
			{
				%obj.schedule(25,"doorCreate",%client,1,1,0);
			}
			else
			{
				%obj.schedule(25,"doorCreate",%client,1,0,0);
			}
		}
	}

	function fxDTSBrick::onRemove(%obj)
	{
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(isObject(%obj.Door))
			{
				%obj.Door.delete();
			}

			%obj.Door = "";

			if(isObject(%obj.ghostDoor))
			{
				%obj.ghostDoor.delete();
			}

			%obj.ghostDoor = "";

			DoorListSO.remove(%obj);
		}

		Parent::onRemove(%obj);
	}

	function fxDTSBrick::setColor(%obj,%colorID)
	{
		if(%colorID $= "")
		{
			%colorID = 0;
		}

		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			if(isObject(%obj.ghostDoor))
			{
				%color = getColorIDTable(%colorID);
				%r = getWord(%color,0);
				%g = getWord(%color,1);
				%b = getWord(%color,2);
				%obj.ghostDoor.setNodeColor("ALL",%r SPC %g SPC %b SPC 1);
			}

			if(isObject(%obj.Door))
			{
				%color = getColorIDTable(%colorID);
				%r = getWord(%color,0);
				%g = getWord(%color,1);
				%b = getWord(%color,2);
				%color1 = %r SPC %g SPC %b SPC 1;
				%color2 = %r * 0.75 SPC %g * 0.75 SPC %b * 0.75 SPC 1;

				for(%i = 0;%i < DoorSO.doorGroups[%doorID];%i++)
				{
					%color = DoorSO.doorGroupColor[%i @ "_" @ %doorID];
					%group = DoorSO.doorGroupName[%i @ "_" @ %doorID];

					if(%color $= "color1")
					{
						%obj.Door.setNodeColor(%group,%color1);
					}
					else if(%color $= "color2")
					{
						%obj.Door.setNodeColor(%group,%color2);
					}
					else
					{
						%obj.Door.setNodeColor(%group,%color);
					}
				}
			}
		}

		Parent::setColor(%obj,%colorID);
	}

	function fxDTSBrick::setTransform(%obj,%transform)
	{
		Parent::setTransform(%obj,%transform);

		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(%doorID > -1)
		{
			%obj.schedule(25,"doorGhostCheck");
		}
		else
		{
			if(isObject(%obj.ghostDoor))
			{
				%obj.ghostDoor.delete();
			}

			%obj.ghostDoor = "";
		}
	}

	//Server Commands

	function serverCmdCancelBrick(%client)
	{
		%obj = %client.Player.tempBrick;
		%error = 0;
		%doorID = -1;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}

		if(isObject(%obj) && %doorID > -1)
		{
			if(isObject(%obj.ghostDoor))
			{
				%obj.ghostDoor.delete();
			}

			%obj.ghostDoor = "";
		}

		Parent::serverCmdCancelBrick(%client);
	}

	function serverCmdClearAllDoors(%client)
	{
		%error = 0;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if((%client.isAdmin == 1 || %client.isSuperAdmin == 1) && %error != 1)
		{
			%numDoors = DoorListSO.getCount();
			%doors = 0;

			for(%i = 1;%i <= %numDoors;%i++)
			{
				%object = DoorListSO.Door[%i];

				if(isObject(%object))
				{
					%door[%doors++] = %object;
				}
			}

			if(%doors > 0)
			{
				for(%i = 1;%i <= %doors;%i++)
				{
					if(isObject(%door[%i]))
					{
						%door[%i].delete();
					}

					DoorListSO.remove(%door[%i]);
				}

				for(%i = 0;%i < ClientGroup.getCount();%i++)
				{
					%cl = ClientGroup.getObject(%i);
					%cl.play2d(doorClearSound);
				}

				messageAll('',"\c3" @ %client.name @ "\c0 cleared all Doors.");
			}
		}
		else if(%client.isAdmin == 1 || %client.isSuperAdmin == 1)
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}
	}

	function serverCmdClearDoors(%client)
	{
		%error = 0;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if(%error != 1)
		{
			%numDoors = DoorListSO.getCount();
			%doors = 0;

			for(%i = 1;%i <= %numDoors;%i++)
			{
				%object = DoorListSO.Door[%i];

				if(isObject(%object))
				{
					if(%object.getGroup().client == %client)
					{
						if(isObject(%object))
						{
							%door[%doors++] = %object;
						}
					}
				}
			}

			if(%doors > 0)
			{
				for(%i = 1;%i <= %doors;%i++)
				{
					if(isObject(%door[%i]))
					{
						%door[%i].delete();
					}

					DoorListSO.remove(%door[%i]);
				}

				for(%i = 0;%i < ClientGroup.getCount();%i++)
				{
					%cl = ClientGroup.getObject(%i);
					%cl.play2d(doorClearSound);
				}

				messageAll('',"\c3" @ %client.name @ "\c2 cleared \c3" @ %client.name @ "'s \c2Doors.");
			}
		}
		else
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}
	}

	function serverCmdClearDoorsByName(%client,%name)
	{
		%error = 0;

		if(!isObject(DoorSO))
		{
			%error = 1;
			error("JVS_Doors: DoorSO does not exist!");
		}

		if(!isObject(DoorListSO))
		{
			%error = 1;
			error("JVS_Doors: DoorListSO does not exist!");
		}

		if((%client.isAdmin == 1 || %client.isSuperAdmin == 1) && %error != 1)
		{
			%cl = findClientByName(%name);

			if(isObject(%cl))
			{
				%numDoors = DoorListSO.getCount();
				%doors = 0;

				for(%i = 1;%i <= %numDoors;%i++)
				{
					%object = DoorListSO.Door[%i];

					if(isObject(%object))
					{
						if(%object.getGroup().client == %cl)
						{
							if(isObject(%object))
							{
								%door[%doors++] = %object;
							}
						}
					}
				}

				if(%doors > 0)
				{
					for(%i = 1;%i <= %doors;%i++)
					{
						if(isObject(%door[%i]))
						{
							%door[%i].delete();
						}

						DoorListSO.remove(%door[%i]);
					}

					for(%i = 0;%i < ClientGroup.getCount();%i++)
					{
						%cl = ClientGroup.getObject(%i);
						%cl.play2d(doorClearSound);
					}

					messageAll('',"\c3" @ %client.name @ "\c2 cleared \c3" @ %cl.name @ "'s \c2Doors.");
				}
			}
		}
		else if(%client.isAdmin == 1 || %client.isSuperAdmin == 1)
		{
			error("JVS_Doors: De-activating package.");
			deactivatePackage(jvsDoorsServer);
		}
	}

	function serverCmdPlantBrick(%client)
	{
		%obj = %client.Player.tempBrick;

		if(isObject(%obj))
		{
			%error = 0;
			%doorID = -1;

			if(!isObject(DoorSO))
			{
				%error = 1;
				error("JVS_Doors: DoorSO does not exist!");
			}

			if(!isObject(DoorListSO))
			{
				%error = 1;
				error("JVS_Doors: DoorListSO does not exist!");
			}

			if(%error != 1)
			{
				%doorID = DoorSO.getIDFromDatablockBrick(%obj.dataBlock);
			}
			else
			{
				error("JVS_Doors: De-activating package.");
				deactivatePackage(jvsDoorsServer);
			}

			if(%doorID > -1)
			{
				for(%i = 1;%i <= DoorListSO.getCount();%i++)
				{
					%brick = DoorListSO.getDoorFromID(%i);

					if(isObject(%brick) && %brick.getGroup().client == %client && !%brick.isDead())
					{
						%doors++;
					}
				}

				%max = returnMaxDoors();

				if(%doors < %max)
				{
					Parent::serverCmdPlantBrick(%client);
				}
				else
				{
					if(%max > 1)
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make more than " @ %max @ " Doors.",2,2,2000);
					}
					else if(%max == 1)
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make more than " @ %max @ " Door.",2,2,2000);
					}
					else
					{
						commandToClient(%client,'centerprint',"\c0You are not permitted to make Doors.",2,2,2000);
					}
				}
			}
			else
			{
				Parent::serverCmdPlantBrick(%client);
			}
		}
		else
		{
			Parent::serverCmdPlantBrick(%client);
		}
	}
};

activatePackage(jvsDoorsServer);

//Input Events

registerInputEvent("fxDTSBrick","onDoorBlocked","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorClose","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorCloseCheck","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorClosed","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorLoaded","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorOpen","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorOpened","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorRestore","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorRestricted","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame",1);
registerInputEvent("fxDTSBrick","onDoorStuckPlayer","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "StuckClients GameConnection",1);
registerInputEvent("fxDTSBrick","onDoorStuckVehicle","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "StuckVehicleSpawns fxDTSBrick",1);

//Output Events

registerOutputEvent("fxDTSBrick","doorClose","list Unrestricted 0 Admin 1 BLIDAllow 2 BLIDDeny 3 Mini-Game 4 TrustLevel1 5 TrustLevel2 6" TAB "string 200 72",1);
registerOutputEvent("fxDTSBrick","doorCloseCheck","",1);
registerOutputEvent("fxDTSBrick","doorCreate","",1);
registerOutputEvent("fxDTSBrick","doorDestroy","",1);
registerOutputEvent("fxDTSBrick","doorHide","",1);
registerOutputEvent("fxDTSBrick","doorOpen","list Unrestricted 0 Admin 1 BLIDAllow 2 BLIDDeny 3 Mini-Game 4 TrustLevel1 5 TrustLevel2 6" TAB "list CW 0 CCW 1" TAB "string 200 72",1);

//Default Door Types

DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Cabin.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Cell.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Front.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Garage.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Glass.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_GlassPanel.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_HalfGlass.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Hatch.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Saloon.cs");
DoorSO.addDoorTypeFromFile("Add-Ons/JVS_Doors/types/Door_Security.cs");