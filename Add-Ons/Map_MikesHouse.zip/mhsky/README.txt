This zip file contains 7 - 512 x 512 JPGs suitable for use in a Torque Engine skybox. I created these using digital photos. Didn't get around to making a proper reflection map, sorry.  

These files are made available free of charge to any Torque Engine project so long as you credit me. Any other use is forbidden. Changes to the file are forbidden. This zip file may not be distributed without this text file (readme.txt). 

Sorry about all the restrictions, but I don't want people changing the textures to something sub-par and then  redistributing them with my name still attached 8/. Conversely, I'd be annoyed if someone made a minor change and then claimed this as their own work. 


-Spencer Boomhower

skybox@boomhower.com  

http://www.boomhower.com/Skybox.html

------------------------------

Garage Games Torque Engine: 

http://www.garagegames.com/pg/product/view.php?id=1
