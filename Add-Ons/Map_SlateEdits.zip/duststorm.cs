
datablock ParticleData(DuststormParticle)
{
   textureName          = "base/data/particles/cloud";
   dragCoefficient     = 0.0;
   gravityCoefficient   = 0.0; 
   inheritedVelFactor   = 0.00;
   lifetimeMS           = 10000;
   lifetimeVarianceMS   = 5000;
   useInvAlpha = true;
   spinRandomMin = -5.0;
   spinRandomMax = 5.0;

   colors[0]     = "0.6 0.5 0.3 0.0";
   colors[1]     = "0.55 0.5 0.35 0.5";
   colors[2]     = "0.6 0.4 0.2 0.0";

   sizes[0]      = 40.0;
   sizes[1]      = 50.0;
   sizes[2]      = 50.0;

   times[0]      = 0.05;
   times[1]      = 0.75;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(DuststormEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;

   ejectionOffset = 0.5;
   ejectionOffsetVariance = 0.5;
	

   ejectionVelocity = 0.5;
   velocityVariance = 0.250;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   phiReferenceVel  = 0;
   phiVariance      = 360;

   overrideAdvances = false;
   orientParticles  = false;

	usePlacementForVelocity = 1;

   particles = DuststormParticle;

    uiName = "";
};