%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_Disabled)
{
	error("JVS_DoorsPack0: JVS_Content is disabled and is required by this Add-On.");
}
else if(%error == $Error::AddOn_NotFound)
{
	error("JVS_DoorsPack0: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack1/types/CastleDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack1/types/ScreenDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack1/types/WoodenDoor.cs");
}