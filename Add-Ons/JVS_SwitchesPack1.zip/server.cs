%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_SwitchesPack1: JVS_Content is missing and is required for this Add-On to work.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack1/types/HorizontalButton.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack1/types/HorizontalLever.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack1/types/VerticalButton.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack1/types/VerticalLever.cs");
}
